# serfling/__init__.py

from serfling.serfling import MatrixRegression

__all__ = ["MatrixRegression"]
