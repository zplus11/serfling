# mreg/__init__.py

from mreg.mreg import MatrixRegression

__all__ = ["MatrixRegression"]
